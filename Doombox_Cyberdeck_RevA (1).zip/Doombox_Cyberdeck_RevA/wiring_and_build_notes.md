# Wiring and build notes — Rev A

## Functional architecture
- Pi 5: powered from the user's USB-C power bank at **5 V / 3 A maximum**. This is a constrained supply for a Pi 5; avoid powering the screen or a mechanical HDD from the Pi's USB ports. Heavy USB peripherals may be limited by the Pi's power configuration.
- Display: its own supply, stated as **12 V DC / 2 A**, into the display's own DC barrel input. Verify connector outer/inner dimensions and polarity from the display label/manual.
- Storage: one 2.5-inch SATA mechanical HDD in its own USB-to-SATA enclosure/adapter. Use the existing enclosure if its model, power input and adapter compatibility check out. The HDD is removable by unplugging its enclosure cable after safe unmount/eject; no hot-swap bay or automatic docking.
- Keyboard: external USB keyboard, not built into the case.
- POWER: momentary normally-open button should connect only to a Pi-compatible power-button interface/connector, according to Raspberry Pi 5 documentation. Do not inject external voltage into the button signal.
- SCREEN: guarded maintained switch can be used for the 12 V display supply only if its **DC contact rating** is confirmed suitable for 12 V / 2 A. Wire only according to the exact switch diagram and insulate/strain-relieve connections. A listing's AC rating is not a DC rating.
- RADIO and GPS: labels/positions are placeholders until exact modules are chosen. Prefer switching their enable/control inputs where supported; don't put unknown loads directly through panel switches.
- No master power cutoff for Pi in this revision. Shutdown and power removal strategy is deferred by user request.

## Wiring overview (functional, not a pin-by-pin harness)
1. Pi power bank USB-C output -> intact USB-C-to-USB-C power cable -> Pi 5 USB-C power input.
2. Separate 12 V / 2 A supply -> confirmed-polarity barrel plug -> display DC input; screen toggle only after DC rating and connector are verified.
3. SATA HDD -> USB-to-SATA bridge/enclosure -> Pi USB port. If the HDD enclosure requires external power, power it using its specified supply, not from the Pi.
4. Momentary POWER button -> Pi-compatible power-button input/interface, following the correct Pi 5 documentation for the exact board revision.
5. RADIO/GPS switch terminals -> only the corresponding module's documented enable input or a correctly rated supply path once modules are selected.

## Current budget warning
5 V × 3 A = **15 W nominal** available from the Pi bank. Pi 5 can have transient demand and this supply is below the recommended higher-current supply. Keep screen and HDD separately powered. Do not assume the Pi can reliably power a mechanical HDD plus other USB devices from this bank.

## Safe operating sequence
- Start: connect the Pi supply and boot normally.
- Shutdown: use the OS shutdown command/menu and wait for shutdown to complete before removing Pi power.
- HDD: safely unmount/eject before disconnecting; shutdown first is the simplest conservative approach.
- Do not switch the 12 V display circuit until the exact switch's DC rating, polarity and terminal map are confirmed.

## Still required for manufacturing-ready CAD
- Exact display model or measured width × height × depth and mounting-hole positions
- Exact enclosure/case outer dimensions and chosen fabrication method/material
- Exact momentary button and guarded toggle dimension drawings
- HDD enclosure outside dimensions and connector locations
- Confirmed screen barrel connector size/polarity
- Exact radio/GPS modules
