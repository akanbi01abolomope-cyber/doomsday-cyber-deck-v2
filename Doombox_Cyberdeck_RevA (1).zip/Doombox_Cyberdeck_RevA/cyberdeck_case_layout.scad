// Doomsday Cyberdeck Rev A — fit/layout model, not production-verified.
// Units: mm. OpenSCAD: F6 render; export STL after replacing assumptions with measured parts.
$fn=48;
case_w=430; case_d=320; base_h=78; wall=3; floor_t=3;
lid_t=3; lid_clearance=2;
display_w=315; display_h=195; display_depth=12; // generic 13.3-inch landscape envelope assumption only
pi_w=85; pi_d=56; pi_h=18;
hdd_w=102; hdd_d=70; hdd_h=15; // approximate 2.5-inch drive/enclosure block
screen_margin=8;
show_layout_blocks=true;
show_lid=false;
module rounded_box(w,d,h,r) {
  hull() for (x=[-w/2+r,w/2-r]) for (y=[-d/2+r,d/2-r])
    translate([x,y,0]) cylinder(r=r,h=h);
}
module tray() {
  difference() {
    rounded_box(case_w,case_d,base_h,8);
    translate([0,0,floor_t])
      rounded_box(case_w-2*wall,case_d-2*wall,base_h,6);
    // Front/side cable pass-through placeholders
    translate([0,-case_d/2-0.1,24]) rotate([-90,0,0]) cylinder(d=16,h=wall+1);
    translate([case_w/2-wall-0.1,0,25]) rotate([0,90,0]) cylinder(d=14,h=wall+1);
  }
}
module layout_block(w,d,h) { color([0.65,0.72,0.78,0.75]) translate([-w/2,-d/2,0]) cube([w,d,h]); }
// Tray and internal component placement. Blocks are visualization only and are not bosses.
tray();
if(show_layout_blocks) {
  // Display footprint, near rear edge; actual display bracket must be designed from measurements.
  color([0.15,0.22,0.28,0.45])
    translate([-display_w/2,case_d/2-display_h-18,base_h-2])
      cube([display_w,display_h,display_depth]);
  // Pi 5 zone, rear-left
  color([0.1,0.65,0.35,0.85])
    translate([-case_w/2+28,-case_d/2+28,floor_t])
      layout_block(pi_w,pi_d,pi_h);
  // One removable HDD enclosure zone, right side; no hot-swap/docking geometry
  color([0.75,0.5,0.15,0.85])
    translate([case_w/2-hdd_w-28,-case_d/2+28,floor_t])
      layout_block(hdd_w,hdd_d,hdd_h);
  // Power bank / cable management zone, center-front (placeholder envelope)
  color([0.25,0.4,0.8,0.7])
    translate([-70,-case_d/2+28,floor_t])
      layout_block(140,75,28);
  // Screen power supply / wire zone, opposite rear corner
  color([0.7,0.25,0.2,0.6])
    translate([case_w/2-90,case_d/2-90,floor_t])
      layout_block(70,60,30);
}
// Optional flat lid shown separately above the tray for layout visualization.
if(show_lid)
  color([0.25,0.25,0.25,0.35])
    translate([0,0,base_h+8]) rounded_box(case_w,case_d,lid_t,8);
