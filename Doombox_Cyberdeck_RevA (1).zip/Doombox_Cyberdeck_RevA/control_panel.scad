// Cyberdeck control panel — parametric layout prototype (mm)
// Rev A: POWER button + SCREEN/RADIO/GPS toggles. Confirm every cutout from actual hardware.
$fn=80;
panel_w=220; panel_h=65; panel_t=3; corner_r=5;
mount_d=4.2; mount_inset_x=8; mount_inset_y=8;
button_cutout_d=16.2; toggle_cutout_d=12.2; // placeholders only
control_x=[-78,-26,26,78];
label_y=-18; label_size=4; engrave_depth=0.45; engrave=true;
module plate(w,h,t,r) {
  linear_extrude(height=t) hull() {
    translate([-(w/2-r),-(h/2-r)]) circle(r=r);
    translate([(w/2-r),-(h/2-r)]) circle(r=r);
    translate([-(w/2-r),(h/2-r)]) circle(r=r);
    translate([(w/2-r),(h/2-r)]) circle(r=r);
  }
}
module et(x,s,sz=label_size) {
  translate([x,label_y,panel_t-engrave_depth])
    linear_extrude(height=engrave_depth+0.05)
      text(s,size=sz,halign="center",valign="center");
}
difference() {
  plate(panel_w,panel_h,panel_t,corner_r);
  for (x=[-panel_w/2+mount_inset_x,panel_w/2-mount_inset_x])
    for (y=[-panel_h/2+mount_inset_y,panel_h/2-mount_inset_y])
      translate([x,y,-0.1]) cylinder(d=mount_d,h=panel_t+0.2);
  translate([control_x[0],6,-0.1]) cylinder(d=button_cutout_d,h=panel_t+0.2);
  for (i=[1:3]) translate([control_x[i],6,-0.1]) cylinder(d=toggle_cutout_d,h=panel_t+0.2);
  if (engrave) {
    et(control_x[0],"POWER",3.5);
    et(control_x[1],"SCREEN",3.3);
    et(control_x[2],"RADIO",3.5);
    et(control_x[3],"GPS",3.5);
  }
}
