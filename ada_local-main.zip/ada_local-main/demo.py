"""
A.D.A - text-only test harness.

Pipeline: your text -> FunctionGemma router -> action executor (timers, tasks,
calendar, search, lights) -> Qwen (via Ollama) writes the reply.

No microphone, speaker, or GPU needed. Run:  python demo.py
"""

import json
import os
import sys
import time
import types
import warnings
from pathlib import Path

warnings.simplefilter("ignore")

# Let ANSI colors work in the Windows terminal
os.system("")

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

# core/__init__.py imports the TTS/audio modules. We don't need them here, so
# register `core` as a bare package to skip that file but keep submodules usable.
_pkg = types.ModuleType("core")
_pkg.__path__ = [str(ROOT / "core")]
sys.modules["core"] = _pkg

import requests  # noqa: E402

from config import RESPONDER_MODEL, OLLAMA_URL, MAX_HISTORY  # noqa: E402

GRAY, RESET, BOLD = "\033[90m", "\033[0m", "\033[1m"
CYAN, GREEN, YELLOW, RED = "\033[36m", "\033[32m", "\033[33m", "\033[31m"

ACTION_FUNCTIONS = {
    "control_light", "set_timer", "set_alarm",
    "create_calendar_event", "add_task", "web_search", "get_system_info",
}

SYSTEM_PROMPT = (
    "You are a helpful desk assistant. Respond in short, complete sentences. "
    "Never use emojis or special characters. Keep responses concise and conversational."
)

http = requests.Session()

# --- Optional speech output (Piper TTS, downloads on first use) ---
speaker = None       # core.tts.tts instance once loaded
SentenceBuffer = None
speaking = False


def set_speech(enable):
    """Turn spoken replies on/off. First enable downloads Piper + a voice."""
    global speaker, SentenceBuffer, speaking
    if not enable:
        speaking = False
        if speaker:
            speaker.stop()
            speaker.enabled = False
        return True
    try:
        from core.tts import tts, SentenceBuffer as SB
    except Exception as e:
        print(f"{RED}Speech needs numpy + sounddevice: {e}{RESET}")
        return False
    if not tts.toggle(True):
        print(f"{RED}Could not start Piper TTS (see messages above).{RESET}")
        return False
    speaker, SentenceBuffer, speaking = tts, SB, True
    return True


def load_backend():
    """Load router + executor. Returns (route_query, executor)."""
    print(f"{GRAY}[System] Loading router (first run downloads ~500MB)...{RESET}")
    from core.llm import route_query
    from core.function_executor import executor

    t = time.time()
    route_query("hello")  # warm-up; loads the model
    print(f"{GRAY}[System] Router ready in {time.time() - t:.1f}s{RESET}")
    return route_query, executor


def check_ollama():
    """Make sure Ollama is up and the model exists."""
    base = OLLAMA_URL.rsplit("/api", 1)[0]
    try:
        r = http.get(f"{base}/api/tags", timeout=3)
        r.raise_for_status()
        names = [m.get("name", "") for m in r.json().get("models", [])]
    except Exception:
        print(f"{RED}Can't reach Ollama at {base}.{RESET} Start it with: ollama serve")
        return False
    if not any(n.startswith(RESPONDER_MODEL) for n in names):
        print(f"{YELLOW}Model '{RESPONDER_MODEL}' not found.{RESET} Run: ollama pull {RESPONDER_MODEL}")
        print(f"{GRAY}Installed: {', '.join(names) or 'none'}{RESET}")
        return False
    return True


def stream_reply(messages, think):
    """Stream a reply from Ollama, printing as it arrives. Returns full text."""
    payload = {
        "model": RESPONDER_MODEL,
        "messages": messages,
        "stream": True,
        "think": think,
        "keep_alive": "5m",
    }
    full, in_thought = "", False
    buf = SentenceBuffer() if speaking else None
    with http.post(f"{OLLAMA_URL}/chat", json=payload, stream=True, timeout=300) as r:
        r.raise_for_status()
        for line in r.iter_lines():
            if not line:
                continue
            try:
                msg = json.loads(line.decode("utf-8")).get("message", {})
            except json.JSONDecodeError:
                continue
            if msg.get("thinking"):
                print(f"{GRAY}{msg['thinking']}{RESET}", end="", flush=True)
                in_thought = True
            if msg.get("content"):
                if in_thought:
                    print(f"{RESET}\n\n", end="", flush=True)
                    in_thought = False
                print(msg["content"], end="", flush=True)
                full += msg["content"]
                if buf:
                    for sentence in buf.add(msg["content"]):
                        speaker.queue_sentence(sentence)
    print()
    if buf:
        rest = buf.flush()
        if rest:
            speaker.queue_sentence(rest)
        speaker.wait_for_completion()
    return full


def describe_result(func_name, result):
    """Turn an executor result into text the LLM can answer from."""
    text = f"Function {func_name} executed. Success: {result.get('success')}. Result: {result.get('message', '')}"
    data = result.get("data")
    if func_name == "web_search" and isinstance(data, dict):
        for item in data.get("results", []):
            text += f"\n- {item.get('title')}: {item.get('body')}"
    elif func_name == "get_system_info" and isinstance(data, dict):
        text += f"\nSystem info: {json.dumps(data, default=str)[:1500]}"
    return text


def main():
    if not check_ollama():
        return
    try:
        route_query, executor = load_backend()
    except Exception as e:
        print(f"{RED}Failed to load router: {e}{RESET}")
        return

    print(f"\n{BOLD}A.D.A text mode{RESET}  (responder: {RESPONDER_MODEL})")
    print(f"{GRAY}Commands: /tts on|off speak replies, /say <text> test speaker,{RESET}")
    print(f"{GRAY}          /reset clears chat, /think on|off forces thinking, exit quits{RESET}\n")

    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    force_think = None  # None = let the router decide

    while True:
        try:
            user_input = input(f"{BOLD}You:{RESET} ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nGoodbye!")
            break
        if not user_input:
            continue

        cmd = user_input.lower()
        if cmd in ("exit", "quit"):
            print("Goodbye!")
            break
        if cmd == "/reset":
            messages = messages[:1]
            print(f"{GRAY}Chat history cleared.{RESET}")
            continue
        if cmd in ("/tts on", "/tts off"):
            if set_speech(cmd.endswith("on")):
                print(f"{GRAY}Speech {'ON' if speaking else 'OFF'}.{RESET}")
            continue
        if cmd.startswith("/say "):
            if speaking or set_speech(True):
                speaker.queue_sentence(user_input[5:])
                speaker.wait_for_completion()
            continue
        if cmd in ("/think on", "/think off"):
            force_think = cmd.endswith("on")
            print(f"{GRAY}Thinking forced {'ON' if force_think else 'OFF'}.{RESET}")
            continue

        try:
            # 1) Route
            t0 = time.time()
            func_name, params = route_query(user_input)
            print(f"{GRAY}[Router {time.time() - t0:.2f}s] -> {func_name} {json.dumps(params, default=str)}{RESET}")

            # 2) Execute action (if any) and build the prompt for the LLM
            if func_name in ACTION_FUNCTIONS:
                result = executor.execute(func_name, params)
                color = GREEN if result.get("success") else YELLOW
                print(f"{color}[Action] {result.get('message')}{RESET}")
                prompt = (
                    f"{describe_result(func_name, result)}\n\n"
                    f"User asked: {user_input}\n\nRespond naturally and concisely."
                )
                think = False
            else:
                prompt = user_input
                think = func_name == "thinking"

            if force_think is not None:
                think = force_think

            # 3) Keep history bounded, then reply
            if len(messages) > MAX_HISTORY:
                messages = [messages[0]] + messages[-(MAX_HISTORY - 1):]
            messages.append({"role": "user", "content": prompt})

            print(f"{BOLD}AI:{RESET} ", end="", flush=True)
            t1 = time.time()
            reply = stream_reply(messages, think)
            print(f"{GRAY}[Responder {time.time() - t1:.1f}s | thinking={think}]{RESET}\n")
            messages.append({"role": "assistant", "content": reply})

        except requests.exceptions.ConnectionError:
            print(f"\n{RED}Lost connection to Ollama. Is it running?{RESET}")
            if messages and messages[-1]["role"] == "user":
                messages.pop()
        except Exception as e:
            print(f"\n{RED}Error: {e}{RESET}")
            if messages and messages[-1]["role"] == "user":
                messages.pop()


if __name__ == "__main__":
    main()
