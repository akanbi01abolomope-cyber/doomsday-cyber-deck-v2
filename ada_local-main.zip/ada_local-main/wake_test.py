"""
Wake word + speech test (CPU).

Say "jarvis", wait for the message, then speak a sentence.
Press Ctrl+C to quit.
"""

from RealtimeSTT import AudioToTextRecorder


def on_wake():
    print("\n>>> Wake word heard! Speak now...")


if __name__ == "__main__":
    print("Loading... (first run downloads the speech model)")
    recorder = AudioToTextRecorder(
        model="tiny",            # try "base" if transcription is inaccurate
        language="en",
        device="cpu",
        compute_type="int8",
        spinner=False,
        wakeword_backend="pvporcupine",
        wake_words="jarvis",
        wake_words_sensitivity=0.5,
        on_wakeword_detected=on_wake,
    )
    print("Say 'jarvis', then speak a sentence. Ctrl+C to quit.")
    while True:
        text = recorder.text()
        print("You said:", text)
