"""
Camera + face tracking test for the desk robot.

Run:   python camera_test.py            (opens camera 0)
       python camera_test.py --list     (finds which camera numbers work)
       python camera_test.py --cam 1    (use camera number 1)

Press q or Esc in the video window to quit.
"""

import argparse
import sys
import time

import cv2

WIDTH, HEIGHT = 640, 480
LOST_AFTER = 2.0          # seconds without a face before state becomes "idle"
SMOOTHING = 0.3           # 0..1, higher = follows faster but jitters more
PAN_RANGE, TILT_RANGE = 45, 30   # max degrees away from centre (90)


def open_camera(index):
    # CAP_DSHOW starts much faster than the default backend on Windows
    cap = cv2.VideoCapture(index, cv2.CAP_DSHOW)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, HEIGHT)
    return cap


def list_cameras():
    print("Checking camera numbers 0-4...")
    found = False
    for i in range(5):
        cap = open_camera(i)
        ok, frame = cap.read() if cap.isOpened() else (False, None)
        cap.release()
        if ok:
            print(f"  Camera {i}: works ({frame.shape[1]}x{frame.shape[0]})")
            found = True
    if not found:
        print("  No camera found. Check it is plugged in and that Windows camera")
        print("  privacy is on: Settings > Privacy & security > Camera >")
        print("  'Let desktop apps access your camera'.")


def load_detector():
    path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    detector = cv2.CascadeClassifier(path)
    if detector.empty():
        sys.exit(f"Could not load face detector from {path}")
    return detector


def find_largest_face(detector, frame):
    """Return (x, y, w, h) of the biggest face in full-frame pixels, or None."""
    small = cv2.resize(frame, None, fx=0.5, fy=0.5)      # half size = 4x faster
    gray = cv2.equalizeHist(cv2.cvtColor(small, cv2.COLOR_BGR2GRAY))
    faces = detector.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5,
                                      minSize=(30, 30))
    if len(faces) == 0:
        return None
    x, y, w, h = max(faces, key=lambda f: f[2] * f[3])
    return int(x * 2), int(y * 2), int(w * 2), int(h * 2)


def face_offset(face, frame_w, frame_h):
    """How far the face centre is from the image centre, each in -1..1."""
    x, y, w, h = face
    dx = ((x + w / 2) - frame_w / 2) / (frame_w / 2)
    dy = ((y + h / 2) - frame_h / 2) / (frame_h / 2)
    return dx, dy


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true", help="list working cameras")
    ap.add_argument("--cam", type=int, default=0, help="camera number")
    args = ap.parse_args()

    if args.list:
        list_cameras()
        return

    cap = open_camera(args.cam)
    if not cap.isOpened():
        sys.exit(f"Could not open camera {args.cam}. Try: python camera_test.py --list")

    detector = load_detector()
    print("Camera running. Press q or Esc in the video window to quit.")

    pan = tilt = 90.0        # servo angles the robot head WOULD use (90 = centre)
    last_seen = 0.0
    state = "idle"
    last_print = 0.0

    while True:
        ok, frame = cap.read()
        if not ok:
            print("Lost the camera feed.")
            break
        frame = cv2.flip(frame, 1)               # mirror view feels natural
        h, w = frame.shape[:2]
        now = time.time()

        face = find_largest_face(detector, frame)
        if face:
            last_seen = now
            dx, dy = face_offset(face, w, h)
            target_pan = 90 + dx * PAN_RANGE
            target_tilt = 90 + dy * TILT_RANGE
            pan += (target_pan - pan) * SMOOTHING
            tilt += (target_tilt - tilt) * SMOOTHING
            x, y, fw, fh = face
            cv2.rectangle(frame, (x, y), (x + fw, y + fh), (0, 255, 0), 2)
            new_state = "tracking"
        else:
            new_state = "tracking" if now - last_seen < LOST_AFTER else "idle"

        if new_state != state:
            state = new_state
            print(f"[state] {state}")            # later: send this to the robot face

        if now - last_print > 0.5 and state == "tracking" and face:
            print(f"  face offset dx={dx:+.2f} dy={dy:+.2f}  ->  pan={pan:.0f}  tilt={tilt:.0f}")
            last_print = now

        cv2.drawMarker(frame, (w // 2, h // 2), (255, 255, 255),
                       cv2.MARKER_CROSS, 20, 1)
        cv2.putText(frame, f"{state}  pan={pan:.0f} tilt={tilt:.0f}", (10, 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
        cv2.imshow("Desk robot camera (q to quit)", frame)

        if cv2.waitKey(1) & 0xFF in (ord("q"), 27):
            break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
